import React from 'react'
import NavbarComponent from '../../components/NavigationBar'
import AboutUsPage from '../aboutUs'
import TeamPage from '../team'
import { HomePage } from './homePage'

const Home = () => {
  return (
    <div>
    <HomePage />
    <AboutUsPage />
    <TeamPage /></div>
  )
}

export default Home