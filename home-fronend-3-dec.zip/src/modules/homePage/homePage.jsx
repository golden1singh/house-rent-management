import React from 'react'

export const HomePage = () => {
  return (
    <section id="home">
    <div className="container">
      <div className="row">
        <div className="col-md-offset-2 col-md-8">
          <h1 className="wow fadeIn" data-wow-offset="50" data-wow-delay="0.9s">
            We make websites that are <span>awesome</span>
          </h1>
          <div className="element fadeIn">
            <div className="sub-element">Hello, This is a HTML Website.</div>
            <div className="sub-element">Awesome Website is Designed and provided by Giri Designs.</div>
            <div className="sub-element">If you need this website, Please contact us.</div>
          </div>
          <a data-scroll href="#about" className="btn btn-default wow fadeInUp" data-wow-offset="50" data-wow-delay="0.6s">
            GET STARTED
          </a>
        </div>
      </div>
    </div>
  </section>
  )
}
