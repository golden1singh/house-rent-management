import React, { useState } from 'react';
import axios from 'axios';
import "../../assets/plotPage.css"
import { API_URL } from '../../service/constant';
import { mainAxios } from '../../service/api';

const AddPlot = () => {
  const [formData, setFormData] = useState({
    plotNumber: '',
    area: '',
    address: '',
    ownerName: '',
  });

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData({ ...formData, [name]: value });
  };

  const handleSubmit = async (e) => {
      console.log({formData})
    e.preventDefault();
    try {
      const response = await mainAxios.post(`${API_URL}/plots/addplots`, formData);
      alert('Plot added successfully!');
      setFormData({ plotNumber: '', area: '', address: '', ownerName: '' });
    } catch (error) {
      console.error('Error adding plot:', error);
      alert('Failed to add plot.');
    }
  };

  return (
      <div className='plotPage'>
    <div className="addPlotPage">
      <h2>Add Plot</h2>
      <form onSubmit={handleSubmit}>
        <div className="form-group">
          <label>Plot Number:</label>
          <input
            type="text"
            name="plotNumber"
            value={formData.plotNumber}
            onChange={handleChange}
            required
          />
        </div>
        <div className="form-group">
          <label>Area:</label>
          <input
            type="text"
            name="area"
            value={formData.area}
            onChange={handleChange}
            required
          />
        </div>
        <div className="form-group">
          <label>Address:</label>
          <input
            type="text"
            name="address"
            value={formData.address}
            onChange={handleChange}
            required
          />
        </div>
        <div className="form-group">
          <label>Owner Name:</label>
          <input
            type="text"
            name="ownerName"
            value={formData.ownerName}
            onChange={handleChange}
            required
          />
        </div>
        <button type="submit" className="submit-btn">
          Add Plot
        </button>
      </form>
    </div></div>
  );
};

export default AddPlot;
