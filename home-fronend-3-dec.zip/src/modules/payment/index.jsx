import React, { useState, useEffect } from "react";
import axios from "axios";
import { mainAxios } from "../../service/api";
import { API_URL } from "../../service/constant";
import "../../assets/paymentPage.css"

const PaymentPage = () => {
    const [plots, setPlots] = useState([]); // List of available plots
    const [selectedPlot, setSelectedPlot] = useState("");
    const [rooms, setRooms] = useState([]); // List of rooms and tenants
    const [loading, setLoading] = useState(false);


    const getPlot = async () => {
        try {
            const response = await mainAxios.get(`${API_URL}/plots/plotslist`);
            console.log({ response })
            setPlots(response?.data)
        } catch (error) {
            console.log({ error })
        }

    }

    // Fetch plot numbers on page load (example data)
    useEffect(() => {
        
        getPlot()

    }, []);

    // Fetch rooms based on selected plot
    const fetchRooms = async (plotNumber) => {
        setLoading(true);
        try {
            const response = await axios.get(`/api/payment/rooms/${plotNumber}`);
            setRooms(response.data);
        } catch (error) {
            console.error("Error fetching rooms:", error);
        } finally {
            setLoading(false);
        }
    };

    // Handle dropdown change
    const handlePlotChange = (e) => {
        const plotNumber = e.target.value;
        setSelectedPlot(plotNumber);
        fetchRooms(plotNumber);
    };

    return (
        <div className="paymentPage">
            <h1>Payment Tracking</h1>
            <div className="dropdown-container">
                <label htmlFor="plotSelect" className="dropdown-label">Select Plot:</label>
                <select
                    id="plotSelect"
                    value={selectedPlot}
                    onChange={handlePlotChange}
                    className="dropdown-select"
                >
                    <option value="">-- Select a Plot --</option>
                    {plots.map((plot, index) => (
                        <option key={index} value={plot?.plotNumber}>
                            {plot?.plotNumber},{plot?.area}
                        </option>
                    ))}
                </select>
            </div>

            {loading ? (
                <p>Loading rooms and tenants...</p>
            ) : rooms.length > 0 ? (
                <div className="roomContainer">
                    {rooms.map((room) => (
                        <div className="roomCard" key={room._id}>
                            <h3>Room {room.roomNumber}</h3>
                            {room.tenant ? (
                                <div className="tenantDetails">
                                    <p><strong>Tenant:</strong> {room.tenant.name}</p>
                                    <p><strong>Contact:</strong> {room.tenant.contact}</p>
                                    <p><strong>Rent Paid:</strong> {room.tenant.rentPaid ? "Yes" : "No"}</p>
                                    <p><strong>Utilities Paid:</strong> {room.tenant.utilityPaid ? "Yes" : "No"}</p>
                                    <button className="payNowBtn">Pay Now</button>
                                </div>
                            ) : (
                                <p>No tenant in this room.</p>
                            )}
                        </div>
                    ))}
                </div>
            ) : (
                <p>No rooms found for the selected plot.</p>
            )}
        </div>
    );
};

export default PaymentPage;
