import React from 'react';

const AboutUsPage = () => {
  return (
    <section id="about" className="about-us-section">
      <div className="container">
        <div className="row">
          <div className="col-md-12">
            <h2 className="wow bounceIn" data-wow-offset="50" data-wow-delay="0.3s">
              WE ARE <span>AWESOME</span>
            </h2>
          </div>
          <div className="col-md-4 col-sm-4 col-xs-12 wow fadeInLeft" data-wow-offset="50" data-wow-delay="0.6s">
            <div className="media">
              <div className="media-heading-wrapper">
                <div className="media-object pull-left">
                  <i className="fa fa-mobile"></i>
                </div>
                <h3 className="media-heading">FULLY RESPONSIVE</h3>
              </div>
              <div className="media-body">
                <p>
                  Lorem ipsum dolor sit amet, consectetur adipiscing elit quisque tempus ac eget diam et laoreet phasellus ut nisi id leo molestie. Adipiscing vitae vel quam proin eget mauris eget. Lorem ipsum dolor sit amet.
                </p>
              </div>
            </div>
          </div>
          <div className="col-md-4 col-sm-4 col-xs-12 wow fadeInUp" data-wow-offset="50" data-wow-delay="0.9s">
            <div className="media">
              <div className="media-heading-wrapper">
                <div className="media-object pull-left">
                  <i className="fa fa-comment-o"></i>
                </div>
                <h3 className="media-heading">FREE SUPPORT</h3>
              </div>
              <div className="media-body">
                <p>
                  Lorem ipsum dolor sit amet, consectetur adipiscing elit quisque tempus ac eget diam et laoreet phasellus ut nisi id leo molestie. Adipiscing vitae vel quam proin eget mauris eget. Lorem ipsum dolor sit amet.
                </p>
              </div>
            </div>
          </div>
          <div className="col-md-4 col-sm-4 col-xs-12 wow fadeInRight" data-wow-offset="50" data-wow-delay="0.6s">
            <div className="media">
              <div className="media-heading-wrapper">
                <div className="media-object pull-left">
                  <i className="fa fa-html5"></i>
                </div>
                <h3 className="media-heading">HTML5 & CSS3</h3>
              </div>
              <div className="media-body">
                <p>
                  Lorem ipsum dolor sit amet, consectetur adipiscing elit quisque tempus ac eget diam et laoreet phasellus ut nisi id leo molestie. Adipiscing vitae vel quam proin eget mauris eget. Lorem ipsum dolor sit amet.
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default AboutUsPage;
