import React, { useState, useEffect } from "react";
import { mainAxios } from "../../service/api";
import { API_URL } from "../../service/constant";
import { toast } from "react-toastify";

const AddTenantForm = () => {
  const [formData, setFormData] = useState({
    name: "",
    contact: "",
    roomNumber: "",
    plotNumber: "",
    depositPaid: "",
    monthlyRent: "",
    entryDate: "",
    aadharCard: null,
    photo: null,
    additionalDocuments: [],
  });

  const [plots, setPlots] = useState([]);
  const [rooms, setRooms] = useState([]);
  const [dynamicDocuments, setDynamicDocuments] = useState([]);

  // Fetch the list of plots
  useEffect(() => {
    const fetchPlots = async () => {
      try {
        const response = await mainAxios.get(`${API_URL}/plots/plotslist`);
        setPlots(response.data);
      } catch (error) {
        console.error("Error fetching plots:", error);
      }
    };
    fetchPlots();
  }, []);

  // Fetch rooms based on selected plot
  const fetchRooms = async (plotNumber) => {
    try {
      const response = await mainAxios.get(`${API_URL}/rooms/list/${plotNumber}`);
      setRooms(response.data);
    } catch (error) {
      console.error("Error fetching rooms:", error);
      toast.error("Failed to fetch rooms.");
    }
  };

  // Handle form input changes
  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData((prevData) => ({
      ...prevData,
      [name]: value,
    }));

    // If plotNumber changes, fetch available rooms
    if (name === "plotNumber") {
      fetchRooms(value);
    }
  };

  // Handle file inputs
  const handleFileChange = (e) => {
    const { name, files } = e.target;
    setFormData((prevData) => ({
      ...prevData,
      [name]: name === "additionalDocuments" ? files : files[0],
    }));
  };

  // Handle dynamic document changes
  const handleDynamicFileChange = (e, index) => {
    const updatedDocuments = [...dynamicDocuments];
    updatedDocuments[index] = e.target.files[0];
    setDynamicDocuments(updatedDocuments);
  };

  // Add a new dynamic document field
  const addDynamicDocumentField = () => {
    setDynamicDocuments([...dynamicDocuments, null]);
  };

  // Remove a dynamic document field
  const removeDynamicDocumentField = (index) => {
    const updatedDocuments = dynamicDocuments.filter((_, i) => i !== index);
    setDynamicDocuments(updatedDocuments);
  };

  // Submit the form
  const handleSubmit = async (e) => {
    e.preventDefault();
    const form = new FormData();

    // Append basic fields
    Object.keys(formData).forEach((key) => {
      if (key !== "additionalDocuments") {
        form.append(key, formData[key]);
      }
    });

    // Append Aadhar card and photo
    if (formData.aadharCard) form.append("aadharCard", formData.aadharCard);
    if (formData.photo) form.append("photo", formData.photo);

    // Append dynamic additional documents
    dynamicDocuments.forEach((file, index) => {
      if (file) form.append(`additionalDocument_${index}`, file);
    });

    try {
      const response = await mainAxios.post(`${API_URL}/tenants/add`, form, {
        headers: { "Content-Type": "multipart/form-data" },
      });
      toast.success("Tenant added successfully!");
      console.log("Response:", response.data);
    } catch (error) {
      console.error("Error adding tenant:", error);
      toast.error("Failed to add tenant.");
    }
  };

  return (
    <div className="add-tenant-form addTenantPage">
      <h2>Add Tenant</h2>
      <form onSubmit={handleSubmit}>
        {/* Basic fields */}
        <div className="form-group">
          <label>Name</label>
          <input
            type="text"
            name="name"
            value={formData.name}
            onChange={handleInputChange}
            required
          />
        </div>
        <div className="form-group">
          <label>Contact</label>
          <input
            type="text"
            name="contact"
            value={formData.contact}
            onChange={handleInputChange}
            required
          />
        </div>
        {/* Plot and Room dropdowns */}
        <div className="form-group">
          <label>Plot</label>
          <select
            name="plotNumber"
            value={formData.plotNumber}
            onChange={handleInputChange}
            required
          >
            <option value="" disabled>
              Select a Plot
            </option>
            {plots.map((plot) => (
              <option key={plot._id} value={plot.plotNumber}>
                {plot.plotNumber} - {plot.area}
              </option>
            ))}
          </select>
        </div>
        <div className="form-group">
          <label>Room</label>
          <select
            name="roomNumber"
            value={formData.roomNumber}
            onChange={handleInputChange}
            required
          >
            <option value="" disabled>
              Select a Room
            </option>
            {rooms.map((room) => (
              <option key={room._id} value={room.roomNumber}>
                {room.roomNumber}
              </option>
            ))}
          </select>
        </div>
        {/* Deposit, Rent, and Entry Date */}
        <div className="form-group">
          <label>Deposit Paid</label>
          <input
            type="number"
            name="depositPaid"
            value={formData.depositPaid}
            onChange={handleInputChange}
            required
          />
        </div>
        <div className="form-group">
          <label>Monthly Rent</label>
          <input
            type="number"
            name="monthlyRent"
            value={formData.monthlyRent}
            onChange={handleInputChange}
            required
          />
        </div>
        <div className="form-group">
          <label>Entry Date</label>
          <input
            type="date"
            name="entryDate"
            value={formData.entryDate}
            onChange={handleInputChange}
          />
        </div>
        {/* Aadhar and Photo */}
        <div className="form-group">
          <label>Aadhar Card</label>
          <input
            type="file"
            name="aadharCard"
            onChange={handleFileChange}
            accept=".jpg,.jpeg,.png,.pdf"
            required
          />
        </div>
        <div className="form-group">
          <label>Photo</label>
          <input
            type="file"
            name="photo"
            onChange={handleFileChange}
            accept=".jpg,.jpeg,.png"
            required
          />
        </div>
        {/* Dynamic Additional Documents */}
        <div className="dynamic-documents">
          <h4>Additional Documents</h4>
          {dynamicDocuments.map((file, index) => (
            <div key={index} className="dynamic-document-field">
              <input
                type="file"
                onChange={(e) => handleDynamicFileChange(e, index)}
                accept=".jpg,.jpeg,.png,.pdf"
              />
              <button
                type="button"
                onClick={() => removeDynamicDocumentField(index)}
                className="remove-btn"
              >
                Remove
              </button>
            </div>
          ))}
          <button
            type="button"
            onClick={addDynamicDocumentField}
            className="add-btn add-more"
          >
           + Add More Document
          </button>
        </div>
        {/* Submit Button */}
        <button type="submit" className="submit-btn">
          Add Tenant
        </button>
      </form>
    </div>
  );
};

export default AddTenantForm;
