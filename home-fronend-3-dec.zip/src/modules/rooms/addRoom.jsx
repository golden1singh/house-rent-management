import React, { useState, useEffect } from "react";
import axios from "axios";
import "../../assets/room.css"
import { mainAxios } from "../../service/api";
import { API_URL } from "../../service/constant";
import Features from "./coponents/Features";
import { toast } from "react-toastify";

const RoomAddForm = () => {
  const [formData, setFormData] = useState({
    roomNumber: "",
    address: "",
    plot: "",
    lightMeterUnit: 0,
    deposit: 0,
    monthlyRent: 0,
    documents: [],
    features: {
        tap: 1,  // 0 = No, 1 = Yes, 2 = Need Repair
        door: 1,
        window: 1,
        kitchenSink: 1,
      },
  });

  const [plots, setPlots] = useState([]);
  const [selectedFiles, setSelectedFiles] = useState([]);
  const getPlot = async () => {
    try {
        const response = await mainAxios.get(`${API_URL}/plots/plotslist`);
        console.log({ response })
        setPlots(response?.data)
    } catch (error) {
        console.log({ error })
    }

}

  // Fetch plot list from the backend
  useEffect(() => {
   getPlot()
  }, []);

  // Handle input changes
  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({
      ...prev,
      [name]: value,
    }));
  };

  // Handle feature toggles
  const handleFeatureChange = (e) => {
    const { name, value } = e.target;
  
    // Convert the string value into a numeric value: 'yes' -> 1, 'no' -> 0, 'repair' -> 2
    const numericValue = value === 'yes' ? 1 : value === 'no' ? 0 : 2;
  
    setFormData((prevData) => ({
      ...prevData,
      features: {
        ...prevData.features,
        [name]: numericValue,
      },
    }));
  };
  
console.log({formData})
  // Handle file selection
  const handleFileChange = (e) => {
    setSelectedFiles(e.target.files);
  };

  // Submit form data
  const handleSubmit = async (e) => {
    e.preventDefault();
console.log({formData})
    const form = new FormData();
    form.append("roomNumber", formData.roomNumber);
    form.append("address", formData.address);
    form.append("plotNumber", formData.plot);
    form.append("lightMeterUnit", formData.lightMeterUnit);
    form.append("deposit", formData.deposit);
    form.append("monthlyRent", formData.monthlyRent);

    // Append files
    for (let i = 0; i < selectedFiles.length; i++) {
      form.append("documents", selectedFiles[i]);
    }

    // Append features as a JSON string
    form.append("features", JSON.stringify(formData.features));

    try {
      const response = await mainAxios.post(`${API_URL}/rooms/add-tenant`, form, {
        headers: { "Content-Type": "multipart/form-data" },
      });
      toast.success("Room added successfully!");
      console.log(response.data);
    } catch (error) {
      console.error("Error adding room:", error);
      toast.error("Failed to add room.");
    }
  };

  return (
    <div className="room-add-form">
      <h2>Add Room</h2>
      <form onSubmit={handleSubmit}>
        <div className="form-group">
          <label>Room Number</label>
          <input
            type="text"
            name="roomNumber"
            value={formData.roomNumber}
            onChange={handleInputChange}
            required
          />
        </div>
        <div className="form-group">
          <label>Address</label>
          <input
            type="text"
            name="address"
            value={formData.address}
            onChange={handleInputChange}
            required
          />
        </div>
        <div className="form-group">
          <label>Plot</label>
          <select
            name="plot"
            value={formData.plot}
            onChange={handleInputChange}
            required
          >
            <option value="" disabled>
              Select a Plot
            </option>
            {plots.map((plot) => (
              <option key={plot._id} value={plot.plotNumber}>
                {plot.plotNumber} - {plot.area}
              </option>
            ))}
          </select>
        </div>
        <div className="form-group">
          <label>Light Meter Unit</label>
          <input
            type="number"
            name="lightMeterUnit"
            value={formData.lightMeterUnit}
            onChange={handleInputChange}
          />
        </div>
        <div className="form-group">
          <label>Deposit</label>
          <input
            type="number"
            name="deposit"
            value={formData.deposit}
            onChange={handleInputChange}
          />
        </div>
        <div className="form-group">
          <label>Monthly Rent</label>
          <input
            type="number"
            name="monthlyRent"
            value={formData.monthlyRent}
            onChange={handleInputChange}
            required
          />
        </div>
        <div className="form-group">
          <label>Documents</label>
          <input type="file" multiple onChange={handleFileChange} />
        </div>
       <Features formData={formData} handleFeatureChange={handleFeatureChange}/>
        <button type="submit" className="submit-btn">
          Add Room
        </button>
      </form>
    </div>
  );
};

export default RoomAddForm;
