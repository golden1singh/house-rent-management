import React from 'react'

const Features = ({formData,handleFeatureChange}) => {
  return (
    <div className="form-group features">
    <h3>Features</h3>
    
    <div className="feature-item">
      <label>Tap:</label>
      <div className="feature-options">
        <label>
          <input
            type="radio"
            name="tap"
            value="yes"
            checked={formData.features.tap === 1}
            onChange={handleFeatureChange}
          />
          Yes
        </label>
        <label>
          <input
            type="radio"
            name="tap"
            value="no"
            checked={formData.features.tap === 0}
            onChange={handleFeatureChange}
          />
          No
        </label>
        <label>
          <input
            type="radio"
            name="tap"
            value="repair"
            checked={formData.features.tap === 2}
            onChange={handleFeatureChange}
          />
          Need Repair
        </label>
      </div>
    </div>
  
    <div className="feature-item">
      <label>Door:</label>
      <div className="feature-options">
        <label>
          <input
            type="radio"
            name="door"
            value="yes"
            checked={formData.features.door === 1}
            onChange={handleFeatureChange}
          />
          Yes
        </label>
        <label>
          <input
            type="radio"
            name="door"
            value="no"
            checked={formData.features.door === 0}
            onChange={handleFeatureChange}
          />
          No
        </label>
        <label>
          <input
            type="radio"
            name="door"
            value="repair"
            checked={formData.features.door === 2}
            onChange={handleFeatureChange}
          />
          Need Repair
        </label>
      </div>
    </div>
  
    <div className="feature-item">
      <label>Window:</label>
      <div className="feature-options">
        <label>
          <input
            type="radio"
            name="window"
            value="yes"
            checked={formData.features.window === 1}
            onChange={handleFeatureChange}
          />
          Yes
        </label>
        <label>
          <input
            type="radio"
            name="window"
            value="no"
            checked={formData.features.window === 0}
            onChange={handleFeatureChange}
          />
          No
        </label>
        <label>
          <input
            type="radio"
            name="window"
            value="repair"
            checked={formData.features.window === 2}
            onChange={handleFeatureChange}
          />
          Need Repair
        </label>
      </div>
    </div>
  
    <div className="feature-item">
      <label>Kitchen Sink:</label>
      <div className="feature-options">
        <label>
          <input
            type="radio"
            name="kitchenSink"
            value="yes"
            checked={formData.features.kitchenSink === 1}
            onChange={handleFeatureChange}
          />
          Yes
        </label>
        <label>
          <input
            type="radio"
            name="kitchenSink"
            value="no"
            checked={formData.features.kitchenSink === 0}
            onChange={handleFeatureChange}
          />
          No
        </label>
        <label>
          <input
            type="radio"
            name="kitchenSink"
            value="repair"
            checked={formData.features.kitchenSink === 2}
            onChange={handleFeatureChange}
          />
          Need Repair
        </label>
      </div>
    </div>
  </div>
  
  )
}

export default Features