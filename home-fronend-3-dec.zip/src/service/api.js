
import axios from "axios";
import { toast } from "react-toastify";
import { API_URL } from "./constant";







const mainAxios = axios.create({
  baseURL: API_URL,
  headers: {
    "Content-Type": "application/json",
  },
});




// mainAxios.interceptors.request.use(
//   (config) => {
//     const token = localStorage.getItem("user_auth_token"); // Separate token for COPEVAL
//     if (token) {
//       config.headers.Authorization = `Bearer ${token}`;
//     }
   
//     return config;
//   },
//   (error) => Promise.reject(error)
// );


const handleResponseError = (error) => {
  if (error.response) {
    const status = error.response.status;
    switch (status) {
      case 401:
        toast.error("Token Expired!!");
       
        break;
      case 403:
        toast.error("Your session has expired or you don't have the required permissions to access this resource.");
       
        break;
      default:
        break;
    }
  }
  return Promise.reject(error);                             
};



// mainAxios.interceptors.response.use((response) => response, handleResponseError);


export { mainAxios };
