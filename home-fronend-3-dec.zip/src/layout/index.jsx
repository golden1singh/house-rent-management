import React from "react";
import { Outlet } from "react-router-dom";
import NavbarComponent from "../components/NavigationBar";


const Layout = () => {
  return (
    <div>
      <NavbarComponent /> {/* Navbar visible on every page */}
     <div className="container">
     <Outlet /> {/* This renders the content of the current route */}
     </div>
        
     
    </div>
  );
};

export default Layout;
