import React from "react";
import { BrowserRouter as Router, Route, Routes } from "react-router-dom";
import NotFound from "../common/NotFound";
import Layout from "../layout";
import AboutUsPage from "../modules/aboutUs";
// import { AddTenantPage } from "../modules/addUser/component/StepWizard";
import AddTenantPage from "../modules/addUser";

import Home from "../modules/homePage";
import PaymentPage from "../modules/payment";
import AddPlot from "../modules/plot/addPlot";
import RoomAddForm from "../modules/rooms/addRoom";
import TeamPage from "../modules/team";


const RouterPage = () => {
    return (
        <Router>
          <Routes>
        {/* Wrap all routes with the Layout */}
        <Route path="/" element={<Layout />}>
          <Route index element={<Home />} />
          {/* <Route path="about" element={<AboutUsPage />} /> */}
          <Route path="team" element={<TeamPage />} />
          <Route path="/add-user" element={<AddTenantPage />} /> 
          <Route path="/add-plot" element={<AddPlot />} />
          <Route path="/add-room" element={<RoomAddForm />} />
          <Route path="/payment" element={<PaymentPage />} />
         {/* <Route path="portfolio" element={<PortfolioPage />} />
          <Route path="contact" element={<ContactPage />} /> */}
        </Route>
      </Routes>
        </Router>
    );
};

export default RouterPage;
