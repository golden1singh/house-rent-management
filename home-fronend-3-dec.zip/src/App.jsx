import React from 'react';
import { ToastContainer } from 'react-toastify';
import HeaderPage from './components/HeaderPage';
import Navbar from './components/NavigationBar';
import AboutUsPage from './modules/aboutUs';
import { Home } from './modules/homePage';
import LandingPage from './modules/landingPage';
import TeamPage from './modules/team';
import RouterPage from './routes';


const App = () => {
  return (
    <>
    <ToastContainer />
    <RouterPage />
    </>
  );
};

export default App;