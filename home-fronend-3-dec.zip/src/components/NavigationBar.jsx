import React, { useState } from "react";
import { Link } from "react-router-dom";

const NavbarComponent = () => {
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);

  // Toggle sidebar visibility
  const toggleSidebar = () => {
    setIsSidebarOpen(!isSidebarOpen);
  };

  return (
    <div className="myNavbar">
      {/* Main Navbar */}
      <nav className="navbar">
        <div className="container">
          <Link className="navbar-brand" to="/">Awesome</Link>
          
          {/* Navbar Links for Larger Screens */}
          <ul className="navbar-links">
            <li><Link to="/" className="active">Home</Link></li>
            {/* <li><Link to="/about">About</Link></li> */}
            <li><Link to="/payment">Payment</Link></li>
            <li><Link to="/add-user">Add Tenanet</Link></li>
            <li><Link to="/add-plot">Add Plot</Link></li>
            <li><Link to="/add-room">Add Room</Link></li>
            <li><Link to="/room">View Rooms</Link></li>
            <li><Link to="/light-bill">Light Bill</Link></li>
          </ul>

          {/* Mobile Toggler Button */}
          <button className="navbar-toggler" onClick={toggleSidebar}>
            ☰
          </button>
        </div>
      </nav>

      {/* Sidebar for Mobile View */}
      {isSidebarOpen && (
        <div className={`sidebar ${isSidebarOpen ? "open" : ""}`}>
          <button className="close-btn" onClick={toggleSidebar}>X</button>
          <ul className="sidebar-links">
            <li><Link to="/home" onClick={toggleSidebar}>Home</Link></li>
            <li><Link to="/about" onClick={toggleSidebar}>About</Link></li>
            <li><Link to="/team" onClick={toggleSidebar}>Team</Link></li>
            <li><Link to="/services" onClick={toggleSidebar}>Services</Link></li>
            <li><Link to="/portfolio" onClick={toggleSidebar}>Portfolio</Link></li>
            <li><Link to="/contact" onClick={toggleSidebar}>Contact</Link></li>
          </ul>
        </div>
      )}
    </div>
  );
};

export default NavbarComponent;
