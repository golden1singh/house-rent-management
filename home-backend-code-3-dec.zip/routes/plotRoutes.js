const express = require('express');
const router = express.Router();
const Plot = require('../models/plotModel');

router.post('/addplots', async (req, res) => {
  try {
    const { plotNumber, area, address, ownerName } = req.body;
    const newPlot = new Plot({ plotNumber, area, address, ownerName });
    console.log("---->",newPlot)
    await newPlot.save();
    res.status(201).json(newPlot);
  } catch (error) {
    console.error('Error creating plot:', error);
    res.status(500).json({ message: 'Failed to create plot' });
  }
});

// Fetch All Plots

router.get('/plotslist', async (req, res) => {
  try {
    const plots = await Plot.find();
    res.status(200).json(plots);
  } catch (error) {
    console.error('Error fetching plots:', error);
    res.status(500).json({ message: 'Failed to fetch plots' });
  }
});

// Fetch a Single Plot by ID

router.get('/plots/:id', async (req, res) => {
  try {
    const plot = await Plot.findById(req.params.id);
    if (!plot) {
      return res.status(404).json({ message: 'Plot not found' });
    }
    res.status(200).json(plot);
  } catch (error) {
    console.error('Error fetching plot:', error);
    res.status(500).json({ message: 'Failed to fetch plot' });
  }
});

// Update a Plot


router.put('/plots/:id', async (req, res) => {
  try {
    const { plotNumber, area, address, ownerName } = req.body;
    const updatedPlot = await Plot.findByIdAndUpdate(
      req.params.id,
      { plotNumber, area, address, ownerName },
      { new: true }
    );
    res.status(200).json(updatedPlot);
  } catch (error) {
    console.error('Error updating plot:', error);
    res.status(500).json({ message: 'Failed to update plot' });
  }
});

// Delete a Plot


router.delete('/plots/:id', async (req, res) => {
  try {
    await Plot.findByIdAndDelete(req.params.id);
    res.status(200).json({ message: 'Plot deleted successfully' });
  } catch (error) {
    console.error('Error deleting plot:', error);
    res.status(500).json({ message: 'Failed to delete plot' });
  }
});

module.exports = router;
