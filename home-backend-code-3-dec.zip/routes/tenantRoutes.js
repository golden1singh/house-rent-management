const express = require('express');
const multer = require('multer');
const Room = require('../models/roomModel');
const Tenant = require('../models/tenantModel');
const Plot=require('../models/plotModel')
const path = require('path');

const router = express.Router();
// Multer storage configuration for document uploads
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, 'uploads/'); // Folder to store uploaded documents
  },
  filename: (req, file, cb) => {
    cb(null, Date.now() + path.extname(file.originalname)); // Unique filename
  },
});

const upload = multer({ storage });

// Add a new tenant
router.post('/add-tenant', upload.array('documents', 10), async (req, res) => {
  try {
    const { name, contact, roomNumber, plotNumber, depositPaid, monthlyRent } = req.body;

    // Find the room by room number and plot number
    const plot = await Plot.findOne({ plotNumber });
    if (!plot) return res.status(400).send('Invalid plot.');

    const room = await Room.findOne({ roomNumber, plotNumber: plot._id });
    if (!room) return res.status(400).send('Room not found.');
    if (room.isOccupied) return res.status(400).send('Room is already occupied.');

    // Validate depositPaid and monthlyRent
    if (depositPaid < room.deposit / 2) {
      return res.status(400).send(`Deposit should be at least 50% of the room's deposit (${room.deposit / 2}).`);
    }

    const newTenant = new Tenant({
      name,
      contact,
      room: room._id,
      depositPaid,
      monthlyRent,
      documents: req.files.map((file) => file.path),
    });

    await newTenant.save();

    // Update room status
    room.isOccupied = true;
    room.tenant = newTenant._id;
    await room.save();

    res.status(201).send('Tenant added successfully!');
  } catch (err) {
    console.error(err);
    res.status(500).send('Server error.');
  }
});



// Update a tenant's details
router.put('/update/:id', upload.array('documents', 10), async (req, res) => {
  try {
    const { depositPaid, monthlyRent, ...updates } = req.body; // Extract deposit and rent from other fields
    const tenant = await Tenant.findById(req.params.id);
    if (!tenant) return res.status(404).send('Tenant not found.');

    // Validate deposit and monthly rent if provided
    if (depositPaid && depositPaid < tenant.depositPaid) {
      return res.status(400).send('New deposit cannot be less than the current deposit.');
    }
    if (monthlyRent && monthlyRent !== tenant.monthlyRent) {
      tenant.monthlyRent = monthlyRent; // Allow updating the rent
    }

    // Update tenant details dynamically
    Object.keys(updates).forEach(key => {
      tenant[key] = updates[key];
    });

    // Handle document uploads
    if (req.files.length > 0) {
      tenant.documents.push(...req.files.map(file => file.path));
    }

    // Save updates to the tenant
    await tenant.save();
    res.status(200).send('Tenant updated successfully!');
  } catch (err) {
    console.error(err);
    res.status(500).send('Server error.');
  }
});


// Get all tenants
router.get('/', async (req, res) => {
  try {
    const tenants = await Tenant.find().populate('room'); // Populate associated room details
    res.status(200).json(tenants);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Server error.', details: err.message });
  }
});

// Get a specific tenant by ID
router.get('/:id', async (req, res) => {
  try {
    const tenant = await Tenant.findById(req.params.id).populate('room'); // Populate associated room details
    if (!tenant) return res.status(404).json({ error: 'Tenant not found.' });
    res.status(200).json(tenant);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Server error.', details: err.message });
  }
});

// Delete a tenant, update room status, and update room details
router.delete('/remove/:id', async (req, res) => {
  try {
    const tenantId = req.params.id;

    // Find the tenant by ID
    const tenant = await Tenant.findById(tenantId);
    if (!tenant) return res.status(404).send('Tenant not found.');

    // Find the associated room
    const room = await Room.findById(tenant.room);
    if (room) {
      // Update room details
      room.isOccupied = false; // Mark room as vacant
      room.lightMeterUnit = req.body.lightMeterUnit || room.lightMeterUnit; // Update light meter reading if provided
      room.features = {
        ...room.features,
        ...req.body.features, // Update specific room features if provided
      };

      await room.save();
    }

    // Delete the tenant
    await Tenant.findByIdAndDelete(tenantId);

    res.status(200).send('Tenant removed successfully, room updated, and marked as vacant.');
  } catch (err) {
    console.error(err);
    res.status(500).send('Server error.');
  }
});



module.exports = router;
