const express = require('express');
const Payment = require('../models/paymentModel'); // Import the correct Payment model
const Tenant = require('../models/tenantModel');  // Import the Tenant model
const Room = require('../models/roomModel');      // Import the Room model
const Plot =require('../models/plotModel');

const router = express.Router();

router.post('/add', async (req, res) => {
  try {
    const { tenantId, roomId, rentPaid, lastUnit, newUnit, unitPrice, month, description } = req.body;

    // Calculate light bill
    const totalUnits = newUnit - lastUnit;
    const lightBillAmount = totalUnits * unitPrice;

    // Create a new payment record
    const payment = new Payment({
      tenant: tenantId,
      room: roomId,
      rentPaid,
      lightBillPaid: lightBillAmount,
      month,
      description,
    });

    // Save payment and link to tenant
    await payment.save();

    // Optionally, update the tenant record with the new payment
    await Tenant.findByIdAndUpdate(tenantId, { $push: { payments: payment._id } });

    res.status(201).send({
      message: 'Payment recorded successfully!',
      paymentDetails: {
        rentPaid,
        lightBillPaid: lightBillAmount,
        totalUnits,
        description,
      },
    });
  } catch (err) {
    console.error(err);
    res.status(500).send('Server error.');
  }
});


// Get payments report for a specific month
router.get('/reports/:month', async (req, res) => {
  try {
    const payments = await Payment.find({ month: req.params.month })
      .populate('tenant') // Populate tenant details
      .populate('room');  // Populate room details
    res.status(200).json(payments);
  } catch (err) {
    console.error(err);
    res.status(500).send('Server error.');
  }
});
/**
 * 1. Fetch Rooms and Tenants for a Plot
 */
 router.get('/rooms/:plotNumber', async (req, res) => {
   console.log("hello")
  try {
    const { plotNumber } = req.params;
    console.log("plotNumber--->",plotNumber)
    // Fetch the plot to get its ObjectId
    const plot = await Plot.findOne({ plotNumber: plotNumber }); // Find plot by its number
    console.log("plot data--->",plot)
    if (!plot) {
      return res.status(404).json({ message: 'Plot not found' });
    }

    // Use the plot's ObjectId to fetch rooms
    const rooms = await Room.find({ plotNumber: plot._id, isOccupied: true }).populate('tenant');
    console.log("rooms-->",rooms)
    res.status(200).json(rooms);
  } catch (err) {
    console.error(err);
    res.status(500).send('Server error.');
  }
});

/**
 * 2. Update Payment Details
 */
router.post('/update', async (req, res) => {
  try {
    const { tenantId, roomId, rentPaid, lastUnit, newUnit, unitPrice, description } = req.body;

    // Calculate light bill
    const lightUnits = newUnit - lastUnit;
    const lightBillAmount = lightUnits * unitPrice;

    // Update payment record
    const payment = new Payment({
      tenant: tenantId,
      room: roomId,
      rentPaid,
      lightBillPaid: lightBillAmount,
      description,
    });

    await payment.save();

    res.status(200).send({
      message: 'Payment updated successfully!',
      paymentDetails: { rentPaid, lightBillAmount, description },
    });
  } catch (err) {
    console.error(err);
    res.status(500).send('Server error.');
  }
});

/**
 * 3. Fetch Payment History
 */
//  Fetch Payment History: /api/payments/history/:id
router.get('/history/:id', async (req, res) => {
  try {
    const { id } = req.params; // Could be tenantId or roomId
    const payments = await Payment.find({ $or: [{ tenant: id }, { room: id }] })
      .populate('tenant')
      .populate('room');
    res.status(200).json(payments);
  } catch (err) {
    console.error(err);
    res.status(500).send('Server error.');
  }
});

module.exports = router;
