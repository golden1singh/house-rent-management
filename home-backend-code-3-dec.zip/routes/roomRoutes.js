const express = require('express');
const multer = require('multer');
const path = require('path');
const Room = require('../models/roomModel'); // Room model
const Plot = require('../models/plotModel'); // Plot model (ensure this is created and imported)

const router = express.Router();

// Multer storage configuration for document uploads
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, 'uploads/'); // Folder to store uploaded documents
  },
  filename: (req, file, cb) => {
    cb(null, Date.now() + path.extname(file.originalname)); // Unique filename
  },
});

const upload = multer({ storage });

// Route to add a new room
router.post('/add', upload.array('documents', 10), async (req, res) => {
  try {
    const { roomNumber, address, plotNumber, lightMeterUnit, deposit, monthlyRent, features } = req.body;

    // Validate Plot by ID or Plot Number
    const plot = await Plot.findOne({ plotNumber });
    if (!plot) return res.status(400).send('Invalid plot. Plot not found.');

    // Check if the room already exists in the plot
    const existingRoom = await Room.findOne({ roomNumber, plotNumber: plot._id });
    if (existingRoom) return res.status(400).send('Room with this number already exists in the selected plot.');

    // Create a new room
    const newRoom = new Room({
      roomNumber,
      address,
      plotNumber: plot._id,
      lightMeterUnit: lightMeterUnit || 0,
      deposit: deposit || 0,
      monthlyRent: monthlyRent || 0,
      documents: req.files.map((file) => file.path),
      features: {
        tap: features?.tap || 1,
        door: features?.door || 1,
        window: features?.window || 1,
        kitchenSink: features?.kitchenSink || 1,
      },
      tenant: null,
    });

    await newRoom.save();
    res.status(200).send('Room added successfully!');
  } catch (err) {
    console.error(err);
    res.status(500).send('Server error.');
  }
});


// Get all room details
router.get('/', async (req, res) => {
  try {
    const rooms = await Room.find().populate('plot'); // Populate plot details
    res.status(200).json(rooms);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Server error.', details: err.message });
  }
});

// Update room details
router.put('/update/:id', upload.array('documents', 10), async (req, res) => {
  try {
    const { features, lightMeterUnit, deposit, monthlyRent } = req.body;

    // Find the room
    const room = await Room.findById(req.params.id);
    if (!room) return res.status(404).json({ error: 'Room not found.' });

    // Update room details
    if (features) {
      room.features = {
        ...room.features,
        ...features, // Update specific features
      };
    }
    if (lightMeterUnit) room.lightMeterUnit = lightMeterUnit;
    if (deposit) room.deposit = deposit;
    if (monthlyRent) room.monthlyRent = monthlyRent;
    if (req.files.length > 0) {
      room.documents.push(...req.files.map((file) => file.path)); // Add new documents
    }

    // Save updated room
    await room.save();

    res.status(200).json({ message: 'Room updated successfully!', room });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Server error.', details: err.message });
  }
});

// Get room details by ID
router.get('/:id', async (req, res) => {
  try {
    const room = await Room.findById(req.params.id).populate('plot'); // Populate plot details
    if (!room) return res.status(404).json({ error: 'Room not found.' });
    res.status(200).json(room);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Server error.', details: err.message });
  }
});

module.exports = router;
