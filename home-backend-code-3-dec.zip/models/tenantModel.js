const mongoose = require('mongoose');

const tenantSchema = new mongoose.Schema({
  name: { type: String, required: true },
  contact: { type: String, required: true },
  room: { type: mongoose.Schema.Types.ObjectId, ref: 'Room', required: true },
  rentPaid: { type: Boolean, default: false }, // Whether the tenant has paid the rent
  utilityPaid: { type: Boolean, default: false }, // Whether the tenant has paid utilities
  depositPaid: { type: Number, required: true }, // Deposit amount paid by the tenant
  monthlyRent: { type: Number, required: true }, // Monthly rent amount agreed upon
  documents: [{ type: String }], // Store file paths for uploaded documents
  entryDate: { type: Date, default: Date.now }, // Date when the tenant moved in
  payments: [{ type: mongoose.Schema.Types.ObjectId, ref: 'Payment' }],
});

const Tenant = mongoose.model('Tenant', tenantSchema);

module.exports = Tenant;
