const mongoose = require('mongoose');

const paymentSchema = new mongoose.Schema({
  tenant: { type: mongoose.Schema.Types.ObjectId, ref: 'Tenant', required: true },
  room: { type: mongoose.Schema.Types.ObjectId, ref: 'Room', required: true },
  rentPaid: { type: Number, required: true },
  lightBillPaid: { type: Number, required: true },
  month: { type: String, required: true }, // e.g., "November 2024"
  description: { type: String }, // Additional comments or details
  createdAt: { type: Date, default: Date.now },
});

const Payment = mongoose.model('Payment', paymentSchema);

module.exports = Payment;
