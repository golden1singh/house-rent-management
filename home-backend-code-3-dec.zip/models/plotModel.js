const mongoose = require('mongoose');

const plotSchema = new mongoose.Schema({
  plotNumber: { type: String, required: true, unique: true }, // Unique identifier for the plot
  area: { type: String, required: true }, // Area of the plot
  address: { type: String, required: true }, // Address of the plot
  ownerName: { type: String, required: true }, // Owner's name
  createdAt: { type: Date, default: Date.now }, // Automatically stores the creation time
});

const Plot = mongoose.model('Plot', plotSchema);

module.exports = Plot;
