const mongoose = require('mongoose');

const roomSchema = new mongoose.Schema({
  roomNumber: { type: String, required: true },
  address: { type: String, required: true }, // Room address
  plotNumber: { type: mongoose.Schema.Types.ObjectId, ref: 'Plot', required: true }, // Reference to Plot model
  isOccupied: { type: Boolean, default: false },
  lightMeterUnit: { type: Number, default: 0 }, // Meter reading for the light bill
  deposit: { type: Number, required: true }, // Deposit amount for the room
  monthlyRent: { type: Number, required: true }, // Monthly rent for the room
  documents: [{ type: String }], // Store file paths for uploaded documents
  features: {
    tap: { type: Number, enum: [0, 1, 2], default: 1 }, // 0 = No, 1 = Yes, 2 = Need Repair
    door: { type: Number, enum: [0, 1, 2], default: 1 },
    window: { type: Number, enum: [0, 1, 2], default: 1 },
    kitchenSink: { type: Number, enum: [0, 1, 2], default: 1 },
  }, // Track the status of various features in the room
  tenant: { type: mongoose.Schema.Types.ObjectId, ref: 'Tenant' } // Add this field to reference Tenant
});

const Room = mongoose.model('Room', roomSchema);

module.exports = Room;
