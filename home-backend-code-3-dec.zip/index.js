const express = require('express');
const dotenv = require('dotenv');
const cors = require('cors'); // Importing CORS
const connectDB = require('./config/db');
const tenantRoutes = require('./routes/tenantRoutes');
const roomRoutes = require('./routes/roomRoutes');
const paymentRoutes=require('./routes/paymentRoutes')
const plotRoutes=require('./routes/plotRoutes')
const app = express();

// Use CORS middleware to allow cross-origin requests
app.use(cors());

// Load environment variables
dotenv.config();

// Connect to MongoDB
connectDB();


// Middleware to parse JSON
app.use(express.json());

// Use routes
app.use('/api/tenants', tenantRoutes);
app.use('/api/rooms', roomRoutes);
app.use('/api/payment',paymentRoutes)
app.use('/api/plots',plotRoutes)

// Basic route
app.get('/', (req, res) => {
  res.send('API is running...');
});

const PORT = process.env.PORT || 5000;
app.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}`);
});
